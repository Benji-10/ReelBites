/**
 * GET    /api/recipes/:id  — get a single recipe.
 * PUT    /api/recipes/:id  — update a recipe (full or partial).
 * DELETE /api/recipes/:id  — delete a recipe.
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/auth';
import type { RecipeIngredient, RecipeInstruction, RecipeMetadata, RecipeFlag } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  const user = getUserFromRequest(request);
  if (!user) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const recipe = await db.recipe.findUnique({ where: { id } });
    if (!recipe || recipe.userId !== user.id) {
      return NextResponse.json({ error: 'Recipe not found.' }, { status: 404 });
    }

    return NextResponse.json({
      recipe: {
        id: recipe.id,
        title: recipe.title,
        description: recipe.description,
        ingredients: recipe.ingredients as RecipeIngredient[],
        instructions: recipe.instructions as RecipeInstruction[],
        metadata: recipe.metadata as RecipeMetadata[],
        flags: recipe.flags as RecipeFlag[],
        sourceUrl: recipe.sourceUrl,
        sourceCaption: recipe.sourceCaption,
        sourceComments: recipe.sourceComments,
        transcript: recipe.transcript,
        ocrText: recipe.ocrText,
        imageUrl: recipe.imageUrl,
        sourceVideoUrl: recipe.sourceVideoUrl,
        createdAt: recipe.createdAt.toISOString(),
        updatedAt: recipe.updatedAt.toISOString(),
      },
    });
  } catch (err) {
    console.error('Failed to get recipe:', err);
    return NextResponse.json({ error: 'Database unavailable.' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: RouteParams) {
  const user = getUserFromRequest(request);
  if (!user) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 });
  }

  try {
    const existing = await db.recipe.findUnique({ where: { id } });
    if (!existing || existing.userId !== user.id) {
      return NextResponse.json({ error: 'Recipe not found.' }, { status: 404 });
    }

    const allowedFields = [
      'title', 'description', 'ingredients', 'instructions',
      'metadata', 'flags', 'sourceUrl', 'sourceCaption', 'sourceComments',
      'transcript', 'ocrText', 'imageUrl', 'sourceVideoUrl',
    ];

    const data: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (field in body) {
        data[field] = body[field];
      }
    }

    const updated = await db.recipe.update({
      where: { id },
      data: data as never,
    });

    return NextResponse.json({
      recipe: {
        id: updated.id,
        title: updated.title,
        description: updated.description,
        ingredients: updated.ingredients as RecipeIngredient[],
        instructions: updated.instructions as RecipeInstruction[],
        metadata: updated.metadata as RecipeMetadata[],
        flags: updated.flags as RecipeFlag[],
        sourceUrl: updated.sourceUrl,
        sourceCaption: updated.sourceCaption,
        sourceComments: updated.sourceComments,
        transcript: updated.transcript,
        ocrText: updated.ocrText,
        imageUrl: updated.imageUrl,
        sourceVideoUrl: updated.sourceVideoUrl,
        createdAt: updated.createdAt.toISOString(),
        updatedAt: updated.updatedAt.toISOString(),
      },
    });
  } catch (err) {
    console.error('Failed to update recipe:', err);
    return NextResponse.json(
      { error: 'Could not update recipe.' },
      { status: 500 },
    );
  }
}

export async function DELETE(request: NextRequest, { params }: RouteParams) {
  const user = getUserFromRequest(request);
  if (!user) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const existing = await db.recipe.findUnique({ where: { id } });
    if (!existing || existing.userId !== user.id) {
      return NextResponse.json({ error: 'Recipe not found.' }, { status: 404 });
    }

    await db.recipe.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('Failed to delete recipe:', err);
    return NextResponse.json(
      { error: 'Could not delete recipe.' },
      { status: 500 },
    );
  }
}
